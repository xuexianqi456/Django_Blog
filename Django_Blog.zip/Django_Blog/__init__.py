import pymysql

pymysql.install_as_MySQLdb()  # 用pymysql替代MySQLdb
